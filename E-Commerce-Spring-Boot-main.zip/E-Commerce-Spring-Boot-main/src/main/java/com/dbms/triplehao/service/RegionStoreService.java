package com.dbms.triplehao.service;

import com.dbms.triplehao.entity.RegionStore;

import java.util.List;

public interface RegionStoreService {
    List<RegionStore> getRegionStoreList();
}
